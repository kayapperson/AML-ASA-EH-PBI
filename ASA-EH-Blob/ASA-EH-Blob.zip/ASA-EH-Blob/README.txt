02/16/2018
Kay Apperson, PhD
aalabsa-CallStream.txt is downloaded from Azure Portal after Sample Data was created from a streaming job aalbasa.